INSERT INTO Book VALUES (1,'Ross Suarez','B1212',0,'History of Amazon Valley',2);  
INSERT INTO Book VALUES (2,'H S Parkmay','B4232',5,'Language Fundamentals',5);  

INSERT INTO Subscription VALUES (1,'B1212',null,TO_DATE('13-06-2020','dd-MM-yyyy'), 'John');  
INSERT INTO Subscription VALUES (2,'B4232',TO_DATE('15-05-2020','dd-MM-yyyy'),TO_DATE('27-04-2020','dd-MM-yyyy'),'Mark');  
INSERT INTO Subscription VALUES (3,'B1212',null,TO_DATE('23-06-2020','dd-MM-yyyy'),'Peter');  

ALTER TABLE PUBLIC.Subscription
ADD FOREIGN KEY (book_Id) 
REFERENCES PUBLIC.Book(book_Id);