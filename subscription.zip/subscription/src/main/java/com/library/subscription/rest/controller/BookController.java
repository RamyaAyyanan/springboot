package com.library.subscription.rest.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.library.subscription.rest.model.Book;
import com.library.subscription.rest.service.BookService;

@RestController
@RequestMapping("/Books")
public class BookController {

	@Autowired
	BookService BookService;

	@GetMapping
	public List<Book> getBooks() {
		return BookService.fetchAllBooks();
	}
}
