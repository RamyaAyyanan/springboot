package com.JUnit.library.subscription.rest.repository;
 
import org.junit.Test;
import org.junit.runner.RunWith; 
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import java.util.List;
import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase.Replace.NONE;
import com.library.subscription.rest.repository.SubscriptionRepository;
import com.library.subscription.rest.model.Subscription;

@ActiveProfiles("test")
@RunWith(SpringRunner.class)
@DataJpaTest
@AutoConfigureTestDatabase(replace = NONE)
public interface SubscriptionRepositoryTest {

	public static final TestEntityManager entityManager = null;

	   public static final SubscriptionRepository subscriptionRepository = null;

	   @Test
	   public default void whenFindAll() {
		   List<Subscription> subscriptions = subscriptionRepository.findAll();

	       //then
	       assertThat(subscriptions.size()).isEqualTo(3);
	   }
}
