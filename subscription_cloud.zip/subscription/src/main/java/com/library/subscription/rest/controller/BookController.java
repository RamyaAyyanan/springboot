package com.library.subscription.rest.controller;

//import java.util.HashMap;
import java.util.List;
//import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

//import org.springframework.cloud.client.circuitbreaker.CircuitBreakerFactory;
import com.library.subscription.rest.model.Book;
import com.library.subscription.rest.service.BookService;
//import com.library.subscription.rest.service.HttpBinService;

@RestController
@RequestMapping("/Books")
public class BookController {

	@Autowired
	BookService BookService;
	
//	private HttpBinService httpBin;
//	private CircuitBreakerFactory circuitBreakerFactory;
//
//	public BookController(CircuitBreakerFactory circuitBreakerFactory, HttpBinService httpBinService) {
//		this.circuitBreakerFactory = circuitBreakerFactory;
//		this.httpBin = httpBinService;
//	}
//	
//	@GetMapping("/get")
//	public Map get() {
//		return httpBin.get();
//	}
//
//	@GetMapping("/delay/{seconds}")
//	public Map delay(@PathVariable int seconds) {
//		return circuitBreakerFactory.create("delay").run(httpBin.delaySuppplier(seconds), t -> {
//			 
//			Map<String, String> fallback = new HashMap<>();
//			fallback.put("hello", "world");
//			return fallback;
//		});
//	}

	@GetMapping
	public List<Book> getBooks() {
		return BookService.fetchAllBooks();
	}
}
