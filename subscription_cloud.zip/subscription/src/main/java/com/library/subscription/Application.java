package com.library.subscription;
 

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.client.RestTemplateBuilder;
//import org.springframework.cloud.client.circuitbreaker.Customizer;
//import org.springframework.cloud.netflix.hystrix.HystrixCircuitBreakerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestTemplate;

//import com.netflix.hystrix.HystrixCommand;
//import com.netflix.hystrix.HystrixCommandGroupKey;
//import com.netflix.hystrix.HystrixCommandProperties;

@SpringBootApplication 
public class Application {

	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
	}	
	
	@Bean
	public RestTemplate restTemplate() {
		return new RestTemplateBuilder().build();
	}

//	@Bean
//	public Customizer<HystrixCircuitBreakerFactory> defaultConfig() {
//		return factory -> factory.configureDefault(id -> HystrixCommand.Setter
//				.withGroupKey(HystrixCommandGroupKey.Factory.asKey(id))
//				.andCommandPropertiesDefaults(HystrixCommandProperties.Setter().withExecutionTimeoutInMilliseconds(3000)));
//	}

}
