package com.library.subscription.rest.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import com.library.subscription.rest.exception.LibraryExceptionHandler;
import com.library.subscription.rest.model.Subscription;
import com.library.subscription.rest.repository.SubscriptionRepository; 

@Service
public class SubscriptionService {

	@Autowired
	SubscriptionRepository SubscriptionRepository;
	
	@Autowired
	LibraryExceptionHandler libraryExceptionHandler;

	public List<Subscription> fetchAllSubscriptions() {
		return SubscriptionRepository.findAll();
	}
	
	public List<Subscription> fetchbySubscriberName(String subScriberName) {
		return SubscriptionRepository.findBySubscriberName(subScriberName);
	}
	
	@Transactional
	public Subscription setSubscription(Subscription subscription) throws Exception {
		try {
		Subscription subscribe = new Subscription();
		subscribe.setBookId(subscription.getBookId());
		subscribe.setSubscriberName(subscription.getSubscriberName());
		subscribe.setDateSubscribed(subscription.getDateSubscribed());
		subscribe.setDateReturned(subscription.getDateReturned()); 
		return SubscriptionRepository.saveAndFlush(subscribe);
		} catch(Exception e) {
			if(e.getMessage().contains("ConstraintViolationException")) {
				throw new ResponseStatusException(
				          HttpStatus.UNPROCESSABLE_ENTITY, "BookId is not available");
			}
			return subscription;
		}
	}

}
