package com.library.subscription.rest.repository;


import java.util.List; 

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository; 

import com.library.subscription.rest.model.Subscription;
import com.library.subscription.rest.exception.*;

@Repository
public interface SubscriptionRepository extends JpaRepository<Subscription, Integer> {
	public LibraryExceptionHandler libraryExceptionHandler = new LibraryExceptionHandler();
	
	 
	@Query("SELECT t FROM Subscription t WHERE UPPER(t.subscriberName) = UPPER(?1)")
    List <Subscription> findBySubscriberName(String subscriberName);
}
