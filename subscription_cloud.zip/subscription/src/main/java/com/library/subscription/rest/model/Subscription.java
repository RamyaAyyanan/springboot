package com.library.subscription.rest.model;

import java.sql.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
public class Subscription {
 
	@Id 
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@JsonIgnore	
	private Integer id;
	private String subscriberName;
	 @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd-MMM-YYYY")
	private Date dateSubscribed;
	 @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd-MMM-YYYY")
	private Date dateReturned;
	private String bookId;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getSubscriberName() {
		return subscriberName;
	}
	public void setSubscriberName(String subscriberName) {
		this.subscriberName = subscriberName;
	}
	public Date getDateSubscribed() {
		return dateSubscribed;
	}
	public void setDateSubscribed(Date dateSubscribed) {
		this.dateSubscribed = dateSubscribed;
	}
	public Date getDateReturned() {
		return dateReturned;
	}
	public void setDateReturned(Date dateReturned) {
		this.dateReturned = dateReturned;
	}
	public String getBookId() {
		return bookId;
	}
	public void setBookId(String bookId) {
		this.bookId = bookId;
	}
	
	 	 
	
}
