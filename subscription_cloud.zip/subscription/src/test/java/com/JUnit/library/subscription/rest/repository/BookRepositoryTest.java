package com.JUnit.library.subscription.rest.repository;
 
import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase.Replace.NONE;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import com.library.subscription.rest.model.Book;
import com.library.subscription.rest.repository.BookRepository;

@ActiveProfiles("test")
@RunWith(SpringRunner.class)
@DataJpaTest
@AutoConfigureTestDatabase(replace = NONE)
public interface BookRepositoryTest {

	public static final TestEntityManager entityManager = null;

	   public static final BookRepository bookRepository = null;

	   @Test
	   public default void whenFindAll() {
		   List<Book> books = bookRepository.findAll();

	       //then
	       assertThat(books.size()).isEqualTo(3);
	   }
}
