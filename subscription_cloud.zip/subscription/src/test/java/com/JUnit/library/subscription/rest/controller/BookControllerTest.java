package com.JUnit.library.subscription.rest.controller;

import java.util.List;
import static java.util.Collections.singletonList;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import static org.springframework.http.MediaType.APPLICATION_JSON;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.hamcrest.collection.IsCollectionWithSize.hasSize;
import static org.hamcrest.core.Is.is;
import static org.mockito.BDDMockito.given;
import com.library.subscription.rest.controller.BookController;
import com.library.subscription.rest.model.Book;

@RunWith(SpringRunner.class)
@WebMvcTest(BookController.class)
public class BookControllerTest {

	@Autowired
	   private MockMvc mvc;

	   @MockBean
	   private BookController bookController;

	@Test
	public void getBooks() throws Exception {
		Book book = new Book();
		
		List<Book> allBooks = singletonList(book);

	    given(bookController.getBooks()).willReturn(allBooks);
	    
	    mvc.perform(get("Book: GetAll")
	               .contentType(APPLICATION_JSON))
	               .andExpect(status().isOk())
	               .andExpect(jsonPath("$", hasSize(1)))
	               .andExpect(jsonPath("$[0].bookName", is(book.getName())));
		
		 
	}
}
