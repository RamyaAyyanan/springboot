package com.JUnit.library.subscription.rest.controller;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.library.subscription.rest.model.Subscription;
import com.library.subscription.rest.service.SubscriptionService;

import org.springframework.web.bind.annotation.RequestBody;

@RestController
@RequestMapping("/Subscriptions")
public class SubscriptionControllerTest {

	@Autowired
	SubscriptionService SubscriptionService;

	@GetMapping
	public List<Subscription> getSubscriptions(@RequestParam(required = false) String subscriberName) {
		if(StringUtils.isNotEmpty(subscriberName) && StringUtils.isNotBlank(subscriberName)) {
			return SubscriptionService.fetchbySubscriberName(subscriberName);
		} else {
		return SubscriptionService.fetchAllSubscriptions();
		}
	}
	
	@PostMapping
	public Subscription setSubscriptions(@RequestBody Subscription subscription) throws Exception {
		return SubscriptionService.setSubscription(subscription); 
	}
}
